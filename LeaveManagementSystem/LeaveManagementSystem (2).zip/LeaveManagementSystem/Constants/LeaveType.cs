﻿namespace LeaveManagementSystem.Constants
{
    public enum LeaveType
    {
        Sick = 1, 
        Casual,
        Paid,
        Unpaid
    }
}
