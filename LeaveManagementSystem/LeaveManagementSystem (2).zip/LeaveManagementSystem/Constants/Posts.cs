﻿namespace LeaveManagementSystem.Constants
{
    public static  class Posts
    {
        //Admin, Manager, Employee
        public const string Admin = "Admin";

        public const string Manager = "Manager";

        public const string Employee = "Employee";


    }
}
