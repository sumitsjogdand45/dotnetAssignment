﻿namespace LeaveManagementSystem.Constants
{
    public enum Role
    { 
        Employee=1,
        Manager,
        Admin

    }
}
