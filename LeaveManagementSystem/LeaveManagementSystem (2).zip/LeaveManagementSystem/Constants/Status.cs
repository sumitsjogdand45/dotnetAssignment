﻿namespace LeaveManagementSystem.Constants
{
    public enum Status
    {
        Pending = 1,
        Approved ,
        Rejected ,
        Cancelled 
    }
}
