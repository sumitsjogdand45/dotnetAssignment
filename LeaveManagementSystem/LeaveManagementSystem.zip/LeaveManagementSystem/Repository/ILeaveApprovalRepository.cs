﻿namespace LeaveManagementSystem.Repository
{
    public interface ILeaveApprovalRepository
    {

    }
}
