﻿namespace LeaveManagementSystem.Repository
{
    public interface ILeaveBalanceRepository
    {

    }
}
