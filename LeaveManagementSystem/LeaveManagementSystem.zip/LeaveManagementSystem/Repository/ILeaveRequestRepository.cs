﻿namespace LeaveManagementSystem.Repository
{
    public interface ILeaveRequestRepository
    {
    }
}
