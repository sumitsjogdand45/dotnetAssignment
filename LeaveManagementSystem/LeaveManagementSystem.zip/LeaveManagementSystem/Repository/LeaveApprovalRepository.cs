﻿namespace LeaveManagementSystem.Repository
{
    public class LeaveApprovalRepository
    {
    }
}
